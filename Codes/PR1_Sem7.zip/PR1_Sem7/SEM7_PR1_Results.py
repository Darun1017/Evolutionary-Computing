"""
SEM7_PR1_Results.py
====================
Head-to-Head Comparison of 4 Evolutionary Algorithms on a Dynamic 64x64 Map

ALGORITHMS:
  1. CCE-TDCCEA      — Cooperative Co-Evolutionary TD-CCEA (macro/micro split)
  2. TD-CCEA         — Monolithic Trajectory-guided CCEA
  3. SA-TDCCEA       — Sensitivity-Adaptive TD-CCEA (per-weight mutation rates)
  4. Standard CCEA   — Same split as CCE-TDCCEA, no trajectory memory

WORKFLOW:
  Phase 1 — EVOLUTION
    Each algorithm evolves against 7 fixed microRTS bots on a 64×64 map
    that gains progressive blockades each generation (BFS-validated).

  Phase 2 — HEAD-TO-HEAD TOURNAMENT
    The best evolved weights from each algorithm play EVOLVED vs EVOLVED
    on the final (blockaded) map. 10 games per pair (5 as P0, 5 as P1).

  Phase 3 — RESULTS
    ┌ Console matrix (image format) ┐
    │ Wilcoxon signed-rank test      │  → wilcoxon_results.txt
    │ Ablation analysis              │  → ablation_results.txt
    │ JSON summary                   │  → pr1_results.json
    └────────────────────────────────┘

SOURCE REFERENCES:
  - Algorithm code:    COMPARE_ALL.py  (lines 269–604)
  - Dynamic map/BFS:   tdccea_dynamic_env.py (lines 74–201)
  - Base map:          maps/open64x64.xml (64×64, no blockades)
"""

import math, random, time, subprocess, os, json, collections

os.environ["PYTHONIOENCODING"] = "utf-8"

# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
CODES_DIR    = os.path.dirname(SCRIPT_DIR)
MICRORTS_DIR = os.path.join(CODES_DIR, "Simulation", "microrts")

# 64×64 map
MAP_W, MAP_H  = 64, 64
BASE_MAP_PATH  = os.path.join(MICRORTS_DIR, "maps", "open64x64.xml")
TEMP_MAP_PATH  = os.path.join(MICRORTS_DIR, "maps", "temp_pr1_64x64.xml")
TEMP_MAP_REL   = "maps/temp_pr1_64x64.xml"
MAX_CYCLES     = 12000   # more cycles for larger map

WEIGHT_NAMES = [
    "worker_ratio","max_workers","expand_threshold","light_preference",
    "heavy_preference","ranged_preference","barracks_timing","aggression",
    "attack_threshold","defend_radius","target_priority","defense_trigger",
    "counter_rush","tech_switch","economy_pressure","scout_priority",
    "group_attack","second_barracks","worker_fight_ratio","focus_fire",
]
DIMENSIONS    = len(WEIGHT_NAMES)
MACRO_INDICES = [0,1,2,6,14,15,17,18]
MICRO_INDICES = [3,4,5,7,8,9,10,11,12,13,16,19]

OPPONENT_ROTATION = [
    "EconomyMilitaryRush","LightRush","WorkerRush",
    "HeavyDefense","RangedRush","EconomyRush","WorkerRushPlusPlus",
]

# Evolution hyperparameters
N_POP             = 20
K_GAMES           = 3
TOTAL_GENERATIONS = 30
VALIDATION_GAMES  = 5
A_MAX             = 15
DELTA_S           = 0.85
DELTA_F           = 0.20
TOP_PARTNERS      = 3
SENSITIVITY_FILE  = "sensitivity_scores.json"

# Head-to-head tournament
H2H_GAMES = 10   # per matchup pair (5 as P0, 5 as P1)

# Reserved tiles (bases, workers, resources + buffers) for 64×64 map
RESERVED = set()
# Player 0 corner (top-left)
for bx, by in [(0,0),(0,1),(1,1),(2,2),(1,2),(2,1),(3,2),(2,3),(3,3)]:
    RESERVED.add((bx, by))
# Player 1 corner (bottom-right)
for bx, by in [(63,63),(63,62),(62,62),(61,61),(62,61),(61,62),(60,61),(61,60),(60,60)]:
    RESERVED.add((bx, by))

# Dynamic environment — scaled for 64×64 (4× area of 32×32)
WALLS_PER_GEN_EARLY = 6
WALLS_PER_GEN_MID   = 10
WALLS_PER_GEN_LATE  = 14
BREAKABLE_RATIO     = 0.4


# ═══════════════════════════════════════════════════════════════
#  MAP GENERATION + BFS VALIDATION
#  (Adapted from tdccea_dynamic_env.py for 64×64)
# ═══════════════════════════════════════════════════════════════

def bfs_reachable(walls, start, end):
    """BFS to check if `start` can reach `end` avoiding `walls`."""
    if start in walls or end in walls:
        return False
    visited = {start}
    q = collections.deque([start])
    while q:
        x, y = q.popleft()
        if (x, y) == end:
            return True
        for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
            nx, ny = x+dx, y+dy
            if 0 <= nx < MAP_W and 0 <= ny < MAP_H:
                if (nx, ny) not in visited and (nx, ny) not in walls:
                    visited.add((nx, ny))
                    q.append((nx, ny))
    return False


def pick_wall_position(terrain_walls, breakable_positions, gen):
    """Pick a random wall position that doesn't break base-to-base path."""
    base0, base1 = (2, 2), (61, 61)   # 64×64 bases
    all_walls = terrain_walls | breakable_positions
    no_place  = all_walls | RESERVED
    for _ in range(300):
        cx, cy = MAP_W // 2, MAP_H // 2
        spread = 10 + gen // 2  # wider spread for larger map
        x = int(random.gauss(cx, spread))
        y = int(random.gauss(cy, spread))
        x = max(0, min(MAP_W - 1, x))
        y = max(0, min(MAP_H - 1, y))
        if (x, y) in no_place:
            continue
        test_walls = all_walls | {(x, y)}
        if bfs_reachable(test_walls, base0, base1):
            return (x, y)
    return None


def add_walls_for_generation(gen, terrain_walls, breakable_positions):
    """Add progressive blockades for a generation."""
    if gen <= 7:
        n_new = WALLS_PER_GEN_EARLY
    elif gen <= 14:
        n_new = WALLS_PER_GEN_MID
    else:
        n_new = WALLS_PER_GEN_LATE
    new_t, new_b = set(), set()
    for _ in range(n_new):
        pos = pick_wall_position(terrain_walls | new_t,
                                 breakable_positions | new_b, gen)
        if pos is None:
            break
        if random.random() < BREAKABLE_RATIO:
            new_b.add(pos)
        else:
            new_t.add(pos)
    terrain_walls      = terrain_walls | new_t
    breakable_positions = breakable_positions | new_b
    return terrain_walls, breakable_positions, len(new_t), len(new_b)


def write_map_xml(terrain_walls, breakable_positions, path):
    """Write a 64×64 map XML with blockades encoded in the terrain string."""
    all_blockades = terrain_walls | breakable_positions
    terrain = ['0'] * (MAP_W * MAP_H)
    for wx, wy in all_blockades:
        terrain[wy * MAP_W + wx] = '1'
    terrain_str = ''.join(terrain)

    units_xml = [
        '    <rts.units.Unit type="Resource" ID="1" player="-1" x="0" y="0" resources="25" hitpoints="1"></rts.units.Unit>',
        '    <rts.units.Unit type="Resource" ID="2" player="-1" x="0" y="1" resources="25" hitpoints="1"></rts.units.Unit>',
        '    <rts.units.Unit type="Resource" ID="5" player="-1" x="63" y="63" resources="25" hitpoints="1"></rts.units.Unit>',
        '    <rts.units.Unit type="Resource" ID="6" player="-1" x="63" y="62" resources="25" hitpoints="1"></rts.units.Unit>',
        '    <rts.units.Unit type="Base" ID="3" player="0" x="2" y="2" resources="0" hitpoints="10"></rts.units.Unit>',
        '    <rts.units.Unit type="Base" ID="7" player="1" x="61" y="61" resources="0" hitpoints="10"></rts.units.Unit>',
        '    <rts.units.Unit type="Worker" ID="4" player="0" x="1" y="1" resources="0" hitpoints="1"></rts.units.Unit>',
        '    <rts.units.Unit type="Worker" ID="8" player="1" x="62" y="62" resources="0" hitpoints="1"></rts.units.Unit>',
    ]

    xml = f'''<rts.PhysicalGameState width="{MAP_W}" height="{MAP_H}">
  <terrain>{terrain_str}</terrain>
  <players>
    <rts.Player ID="0" resources="5"></rts.Player>
    <rts.Player ID="1" resources="5"></rts.Player>
  </players>
  <units>
{chr(10).join(units_xml)}
  </units>
</rts.PhysicalGameState>'''
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(xml)


# ═══════════════════════════════════════════════════════════════
#  GAME SERVER
#  Supports both EVOLVED vs BOT and EVOLVED vs EVOLVED modes
# ═══════════════════════════════════════════════════════════════

class GameServer:
    def __init__(self):
        self.process = None
        self._fail_count = 0
        self._total_count = 0

    def start(self):
        print(f"  [SERVER] cwd = {MICRORTS_DIR}")
        print(f"  [SERVER] Map file exists: {os.path.isfile(TEMP_MAP_PATH)}")
        self.process = subprocess.Popen(
            ["java", "-cp", "lib/*;bin", "tests.EvolvedBatchGameRunner"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, cwd=MICRORTS_DIR
        )
        line = self.process.stdout.readline().strip()
        if line != "READY":
            # Try to read stderr for more info
            err = ""
            try:
                import select
                err = self.process.stderr.read(2000)
            except Exception:
                pass
            raise RuntimeError(f"Server failed to start: stdout='{line}' stderr='{err}'")
        print(f"  [SERVER] Started successfully (READY)")

    def _check_alive(self):
        """Check if the Java process is still running."""
        if self.process and self.process.poll() is not None:
            rc = self.process.returncode
            err = ""
            try:
                err = self.process.stderr.read(2000)
            except Exception:
                pass
            print(f"  [SERVER ERROR] Java process DIED! exit code={rc}")
            if err:
                print(f"  [SERVER STDERR] {err[:500]}")
            return False
        return True

    def run_game(self, weights, opponent, map_path=None):
        """Run EVOLVED vs BOT. Returns (winner, cycles)."""
        if map_path is None:
            map_path = TEMP_MAP_REL
        self._total_count += 1

        if not self._check_alive():
            self._fail_count += 1
            return -1, MAX_CYCLES

        ws = ";".join(f"{w:.4f}" for w in weights)
        cmd = f"EVOLVED:{ws},{opponent},{map_path},{MAX_CYCLES}\n"
        try:
            self.process.stdin.write(cmd)
            self.process.stdin.flush()
            r = self.process.stdout.readline().strip()
        except (BrokenPipeError, OSError) as e:
            self._fail_count += 1
            if self._fail_count <= 3:
                print(f"  [SERVER ERROR] Pipe broken: {e}")
            return -1, MAX_CYCLES

        if r.startswith("RESULT:"):
            p = r.replace("RESULT:", "").split(",")
            return int(p[0]), int(p[1])

        # Not a valid result — log it
        self._fail_count += 1
        if self._fail_count <= 5:
            print(f"  [SERVER WARNING] Game #{self._total_count}: "
                  f"Expected 'RESULT:...' got '{r[:80]}'")
            if not r:
                print(f"  [SERVER WARNING] Empty response — server likely crashed!")
                self._check_alive()
        return -1, MAX_CYCLES

    def run_game_evolved_vs_evolved(self, p0_weights, p1_weights, map_path=None):
        """Run EVOLVED vs EVOLVED. Returns (winner, cycles)."""
        if map_path is None:
            map_path = TEMP_MAP_REL
        self._total_count += 1

        if not self._check_alive():
            self._fail_count += 1
            return -1, MAX_CYCLES

        w0 = ";".join(f"{w:.4f}" for w in p0_weights)
        w1 = ";".join(f"{w:.4f}" for w in p1_weights)
        req = f"EVOLVED:{w0},EVOLVED:{w1},{map_path},{MAX_CYCLES}\n"
        try:
            self.process.stdin.write(req)
            self.process.stdin.flush()
            resp = self.process.stdout.readline().strip()
        except (BrokenPipeError, OSError) as e:
            self._fail_count += 1
            if self._fail_count <= 3:
                print(f"  [SERVER ERROR] Pipe broken: {e}")
            return -1, MAX_CYCLES

        if resp.startswith("RESULT:"):
            parts = resp.replace("RESULT:", "").split(",")
            return int(parts[0]), int(parts[1])

        self._fail_count += 1
        if self._fail_count <= 5:
            print(f"  [SERVER WARNING] H2H Game #{self._total_count}: "
                  f"Expected 'RESULT:...' got '{resp[:80]}'")
        return -1, MAX_CYCLES

    def run_test_game(self):
        """Run a diagnostic test game to verify the server works."""
        print(f"  [DIAG] Running test game...")
        test_weights = [0.5] * DIMENSIONS
        w, c = self.run_game(test_weights, "WorkerRush")
        if w == -1 and self._fail_count > 0:
            print(f"  [DIAG] *** TEST GAME FAILED! Server may not support this map. ***")
            print(f"  [DIAG] Trying with basesWorkers32x32A.xml...")
            w2, c2 = self.run_game(test_weights, "WorkerRush",
                                   map_path="maps/basesWorkers32x32A.xml")
            if w2 != -1:
                print(f"  [DIAG] 32x32 map works (winner={w2}, cycles={c2})")
                print(f"  [DIAG] Problem is with the 64x64 temp map!")
            else:
                print(f"  [DIAG] 32x32 map also fails — server has deeper issues")
            return False
        else:
            print(f"  [DIAG] Test game OK: winner={w}, cycles={c}")
            return True

    def stop(self):
        if self._fail_count > 0:
            print(f"  [SERVER] Total games: {self._total_count}, "
                  f"Failures: {self._fail_count} "
                  f"({self._fail_count/max(1,self._total_count)*100:.1f}%)")
        if self.process:
            try:
                self.process.stdin.write("EXIT\n")
                self.process.stdin.flush()
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()


# ═══════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════

def euclidean_dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def evaluate_weights(server, weights, opponent):
    """Evaluate weights vs a named bot opponent. Returns win rate [0,1]."""
    wins = 0
    for _ in range(K_GAMES):
        w, _ = server.run_game(weights, opponent)
        if w == 0:    wins += 1
        elif w == -1: wins += 0.3
    return wins / K_GAMES


def validate_weights(server, weights):
    """Validate weights against all 7 bots. Returns (overall%, per_opp dict)."""
    tw = tg = 0
    per_opp = {}
    for opp in OPPONENT_ROTATION:
        ow = 0
        for _ in range(VALIDATION_GAMES):
            w, _ = server.run_game(weights, opp)
            if w == 0: ow += 1
            tg += 1
        tw += ow
        per_opp[opp] = ow / VALIDATION_GAMES * 100
    return tw / tg * 100, per_opp


# ═══════════════════════════════════════════════════════════════
#  WILCOXON SIGNED-RANK TEST
# ═══════════════════════════════════════════════════════════════

def wilcoxon_test(x, y):
    """Pure Python Wilcoxon signed-rank test. Returns p-value or None."""
    diffs = [xi - yi for xi, yi in zip(x, y) if xi != yi]
    if len(diffs) < 3:
        return None
    n     = len(diffs)
    abs_d = sorted(enumerate(abs(d) for d in diffs), key=lambda t: t[1])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j < n - 1 and abs_d[j][1] == abs_d[j+1][1]:
            j += 1
        avg_rank = (i + j) / 2.0 + 1
        for k in range(i, j+1):
            ranks[abs_d[k][0]] = avg_rank
        i = j + 1
    w_plus  = sum(ranks[i] for i, d in enumerate(diffs) if d > 0)
    w_minus = sum(ranks[i] for i, d in enumerate(diffs) if d < 0)
    w_stat  = min(w_plus, w_minus)
    mu_w    = n * (n + 1) / 4.0
    sig_w   = math.sqrt(n * (n + 1) * (2*n + 1) / 24.0)
    if sig_w == 0:
        return None
    z = (w_stat - mu_w) / sig_w
    p = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / math.sqrt(2))))
    return p


# ═══════════════════════════════════════════════════════════════
#  SENSITIVITY ANALYSIS LOADER
# ═══════════════════════════════════════════════════════════════

def run_sensitivity_analysis(server):
    """Run sensitivity analysis to get per-weight mutation rates."""
    print("  Running sensitivity analysis...")
    baseline = [0.5] * DIMENSIONS
    bw = bg = 0
    for opp in OPPONENT_ROTATION:
        for _ in range(K_GAMES):
            w, _ = server.run_game(baseline, opp)
            if w == 0:    bw += 1
            elif w == -1: bw += 0.3
            bg += 1
    baseline_wr = bw / bg
    print(f"  Baseline win rate: {baseline_wr:.1%}")

    influence = []
    for w_idx in range(DIMENSIONS):
        results = []
        for val in [0.0, 1.0]:
            test = baseline[:]
            test[w_idx] = val
            wins = games = 0
            for opp in OPPONENT_ROTATION:
                for _ in range(K_GAMES):
                    w, _ = server.run_game(test, opp)
                    if w == 0:    wins += 1
                    elif w == -1: wins += 0.3
                    games += 1
            results.append(wins / games)
        influence.append(abs(results[1] - results[0]))
        print(f"  w{w_idx:2d} {WEIGHT_NAMES[w_idx]:<22s} influence={influence[-1]:.3f}")

    max_inf    = max(influence) if max(influence) > 0 else 1.0
    normalized = [0.08 + (1.0 - inf / max_inf) * 0.12 for inf in influence]

    data = {
        "influence_scores":          influence,
        "normalized_mutation_rates": normalized,
        "baseline_winrate":          baseline_wr,
        "weight_names":              WEIGHT_NAMES,
    }
    fp = os.path.join(SCRIPT_DIR, SENSITIVITY_FILE)
    with open(fp, "w") as f:
        json.dump(data, f, indent=2)
    print(f"  Saved to {SENSITIVITY_FILE}")
    return normalized


def load_or_run_sensitivity(server):
    """Load sensitivity scores or run analysis if missing."""
    # Check in PR1_Sem7 directory first, then parent Codes directory
    for search_dir in [SCRIPT_DIR, CODES_DIR]:
        fp = os.path.join(search_dir, SENSITIVITY_FILE)
        if os.path.exists(fp):
            print(f"  Loading {fp}...")
            with open(fp) as f:
                data = json.load(f)
            rates = data["normalized_mutation_rates"]
            if min(rates) < 0.07 or max(rates) > 0.21:
                print("  WARNING: sensitivity_scores.json appears stale.")
                break
            return rates
    print(f"  {SENSITIVITY_FILE} not found — running analysis...")
    rates = run_sensitivity_analysis(server)
    return rates


# ═══════════════════════════════════════════════════════════════
#  CCE-TDCCEA CLASSES
#  (From COMPARE_ALL.py — Sub-population cooperative coevolution
#   with trajectory-guided mutation)
# ═══════════════════════════════════════════════════════════════

class SubAgent:
    """Sub-agent for CCE-TDCCEA (handles either macro or micro weights)."""
    def __init__(self, dim, params=None):
        self.dim    = dim
        self.params = ([random.random() for _ in range(dim)] if params is None
                       else [max(0.0, min(1.0, float(x))) for x in params])
        self.H_i  = []
        self.e_i  = 0.0
        self.mu_i = 0.0

    def update_history(self, f, env):
        self.H_i.append((f, env))
        if len(self.H_i) > 7: self.H_i.pop(0)

    def compute_trajectory(self, env):
        if not self.H_i: self.e_i = 0.0; return
        md = math.sqrt(self.dim)
        ws = [max(0.0, 1.0 - euclidean_dist(env[:self.dim], pe[:self.dim]) / md)
              if len(pe) >= self.dim else 1.0 for _, pe in self.H_i]
        t  = sum(ws)
        ws = [w/t for w in ws] if t > 0 else [1.0/len(ws)] * len(ws)
        self.e_i = sum(w * self.H_i[i][0] for i, w in enumerate(ws))

    def compute_mutation(self): self.mu_i = 0.15 * (1.0 - self.e_i) + 0.03

    def mutate(self):
        return SubAgent(self.dim,
            [max(0.0, min(1.0, p + random.gauss(0, self.mu_i))) for p in self.params])


def combine_subagents(macro, micro):
    """Combine macro and micro sub-agents into a full weight vector."""
    full = [0.5] * DIMENSIONS
    for i, idx in enumerate(MACRO_INDICES): full[idx] = macro.params[i]
    for i, idx in enumerate(MICRO_INDICES): full[idx] = micro.params[i]
    return full


def subpop_survival(pop, archive):
    """Survival selection with diversity maintenance and archive."""
    dim  = pop[0].dim
    md   = math.sqrt(dim)
    survivors = []
    for a in sorted(pop, key=lambda a: a.e_i, reverse=True):
        if not any(1.0 - euclidean_dist(a.params, u.params) / md > DELTA_S
                   for u in survivors):
            survivors.append(a)
    final = [a for a in survivors if not (a.e_i < DELTA_F and len(a.H_i) >= 3)]
    while len(final) < 8 and len(survivors) > len(final):
        for a in sorted(survivors, key=lambda a: a.e_i, reverse=True):
            if a not in final: final.append(a); break
    for top in sorted(pop, key=lambda a: a.e_i, reverse=True)[:3]:
        ar = SubAgent(dim, top.params)
        ar.e_i, ar.H_i, ar.mu_i = top.e_i, top.H_i[:], top.mu_i
        archive.append(ar)
    archive.sort(key=lambda a: a.e_i, reverse=True)
    del archive[A_MAX:]
    pool    = final + archive
    new_pop = final[:]
    while len(new_pop) < N_POP:
        cands = random.sample(pool, min(3, len(pool)))
        new_pop.append(max(cands, key=lambda a: a.e_i).mutate())
    return new_pop, archive


# ═══════════════════════════════════════════════════════════════
#  MONOLITHIC AGENT
#  (From COMPARE_ALL.py — used by TD-CCEA and SA-TDCCEA)
# ═══════════════════════════════════════════════════════════════

class Agent:
    """Monolithic agent for TD-CCEA and SA-TDCCEA."""
    def __init__(self, params=None, pwm=None):
        self.params = ([random.random() for _ in range(DIMENSIONS)] if params is None
                       else [max(0.0, min(1.0, float(x))) for x in params])
        self.H_i  = []
        self.e_i  = 0.0
        self.mu_i = 0.0
        self.pwm  = pwm

    def update_history(self, f, env):
        self.H_i.append((f, env))
        if len(self.H_i) > 7: self.H_i.pop(0)

    def compute_trajectory(self, env):
        if not self.H_i: self.e_i = 0.0; return
        md = math.sqrt(DIMENSIONS)
        ws = [max(0.0, 1.0 - euclidean_dist(env, pe) / md) for _, pe in self.H_i]
        t  = sum(ws)
        ws = [w/t for w in ws] if t > 0 else [1.0/len(ws)] * len(ws)
        self.e_i = sum(w * self.H_i[i][0] for i, w in enumerate(ws))

    def compute_mutation(self): self.mu_i = 0.15 * (1.0 - self.e_i) + 0.03

    def mutate(self):
        cp = []
        if self.pwm:
            for j, p in enumerate(self.params):
                sigma_j = self.pwm[j] * (1.0 - self.e_i) + 0.02
                cp.append(max(0.0, min(1.0, p + random.gauss(0, sigma_j))))
        else:
            for p in self.params:
                cp.append(max(0.0, min(1.0, p + random.gauss(0, self.mu_i))))
        return Agent(cp, self.pwm)


# ═══════════════════════════════════════════════════════════════
#  ALGORITHM 1 — CCE-TDCCEA
# ═══════════════════════════════════════════════════════════════

def run_ccea(server):
    """CCE-TDCCEA: Cooperative Co-Evolutionary TD-CCEA."""
    print(f"\n{'='*60}")
    print(f"  RUNNING: CCE-TDCCEA (Our Algorithm)")
    print(f"{'='*60}")
    pop_a = [SubAgent(len(MACRO_INDICES)) for _ in range(N_POP)]
    pop_b = [SubAgent(len(MICRO_INDICES)) for _ in range(N_POP)]
    arc_a, arc_b          = [], []
    top_a, top_b          = pop_a[:TOP_PARTNERS], pop_b[:TOP_PARTNERS]
    best_a, best_b        = pop_a[0], pop_b[0]
    t0                    = time.time()
    convergence           = []

    for gen in range(1, TOTAL_GENERATIONS + 1):
        opp = OPPONENT_ROTATION[(gen - 1) % len(OPPONENT_ROTATION)]
        ca  = [sum(a.params[j] for a in pop_a) / len(pop_a) for j in range(len(MACRO_INDICES))]
        cb  = [sum(b.params[j] for b in pop_b) / len(pop_b) for j in range(len(MICRO_INDICES))]
        env = ca + cb

        for a in pop_a:
            fs = [evaluate_weights(server, combine_subagents(a, pb), opp) for pb in top_b]
            a.update_history(sum(fs)/len(fs), env); a.compute_trajectory(env); a.compute_mutation()

        for b in pop_b:
            fs = [evaluate_weights(server, combine_subagents(pa, b), opp) for pa in top_a]
            b.update_history(sum(fs)/len(fs), env); b.compute_trajectory(env); b.compute_mutation()

        best_a = max(pop_a, key=lambda a: a.e_i)
        best_b = max(pop_b, key=lambda a: a.e_i)
        top_a  = sorted(pop_a, key=lambda a: a.e_i, reverse=True)[:TOP_PARTNERS]
        top_b  = sorted(pop_b, key=lambda a: a.e_i, reverse=True)[:TOP_PARTNERS]
        cmb    = evaluate_weights(server, combine_subagents(best_a, best_b), opp)
        convergence.append(cmb)
        print(f"  Gen {gen:2d}/{TOTAL_GENERATIONS} | {opp:25s} | A={best_a.e_i:.3f} B={best_b.e_i:.3f} Cmb={cmb:.3f}")
        pop_a, arc_a = subpop_survival(pop_a, arc_a)
        pop_b, arc_b = subpop_survival(pop_b, arc_b)

    return combine_subagents(best_a, best_b), time.time() - t0, convergence


# ═══════════════════════════════════════════════════════════════
#  ALGORITHM 2 — STANDARD CCEA
# ═══════════════════════════════════════════════════════════════

def run_standard_ccea(server):
    """Standard CCEA: Same macro/micro split, no trajectory memory."""
    print(f"\n{'='*60}")
    print(f"  RUNNING: Standard CCEA (no trajectory memory)")
    print(f"{'='*60}")
    MUT = 0.15
    pm  = [[random.random() for _ in range(len(MACRO_INDICES))] for _ in range(N_POP)]
    pi  = [[random.random() for _ in range(len(MICRO_INDICES))] for _ in range(N_POP)]
    fm  = [0.0] * N_POP
    fi  = [0.0] * N_POP
    t0  = time.time()
    convergence = []

    def mk(mac, mic):
        f = [0.5] * DIMENSIONS
        for k, idx in enumerate(MACRO_INDICES): f[idx] = mac[k]
        for k, idx in enumerate(MICRO_INDICES): f[idx] = mic[k]
        return f

    def breed(pop, fits):
        bi      = max(range(len(pop)), key=lambda i: fits[i])
        new_pop = [pop[bi][:]]
        while len(new_pop) < N_POP:
            t    = random.sample(range(len(pop)), min(3, len(pop)))
            pidx = max(t, key=lambda i: fits[i])
            new_pop.append([max(0.0, min(1.0, x + random.gauss(0, MUT))) for x in pop[pidx]])
        return new_pop

    for gen in range(1, TOTAL_GENERATIONS + 1):
        opp  = OPPONENT_ROTATION[(gen - 1) % len(OPPONENT_ROTATION)]
        tmi  = sorted(range(N_POP), key=lambda i: fi[i], reverse=True)[:TOP_PARTNERS]
        tma  = sorted(range(N_POP), key=lambda i: fm[i], reverse=True)[:TOP_PARTNERS]
        for i in range(N_POP):
            fs = [evaluate_weights(server, mk(pm[i], pi[j]), opp) for j in tmi]
            fm[i] = sum(fs) / len(fs)
        for i in range(N_POP):
            fs = [evaluate_weights(server, mk(pm[j], pi[i]), opp) for j in tma]
            fi[i] = sum(fs) / len(fs)
        bm  = max(range(N_POP), key=lambda i: fm[i])
        bi2 = max(range(N_POP), key=lambda i: fi[i])
        bf  = evaluate_weights(server, mk(pm[bm], pi[bi2]), opp)
        convergence.append(bf)
        print(f"  Gen {gen:2d}/{TOTAL_GENERATIONS} | {opp:25s} | Best={bf:.3f}")
        pm = breed(pm, fm)
        pi = breed(pi, fi)

    bm  = max(range(N_POP), key=lambda i: fm[i])
    bi2 = max(range(N_POP), key=lambda i: fi[i])
    return mk(pm[bm], pi[bi2]), time.time() - t0, convergence


# ═══════════════════════════════════════════════════════════════
#  ALGORITHMS 3/4 — TD-CCEA / SA-TDCCEA
# ═══════════════════════════════════════════════════════════════

def evolve_core(server, label, pwm=None):
    """Monolithic evolution: TD-CCEA (pwm=None) or SA-TDCCEA (pwm=rates)."""
    print(f"\n{'='*60}")
    print(f"  RUNNING: {label}")
    print(f"{'='*60}")
    population = [Agent(pwm=pwm) for _ in range(N_POP)]
    archive    = []
    t0         = time.time()
    convergence = []

    for gen in range(1, TOTAL_GENERATIONS + 1):
        opp      = OPPONENT_ROTATION[(gen - 1) % len(OPPONENT_ROTATION)]
        centroid = [sum(a.params[j] for a in population) / len(population)
                    for j in range(DIMENSIONS)]
        for agent in population:
            f_i = evaluate_weights(server, agent.params, opp)
            agent.update_history(f_i, centroid)
            agent.compute_trajectory(centroid)
            agent.compute_mutation()
        best = max(population, key=lambda a: a.e_i)
        convergence.append(best.e_i)
        print(f"  Gen {gen:2d}/{TOTAL_GENERATIONS} | {opp:25s} | e_i={best.e_i:.3f}")
        md        = math.sqrt(DIMENSIONS)
        survivors = []
        for a in sorted(population, key=lambda a: a.e_i, reverse=True):
            if not any(1.0 - euclidean_dist(a.params, u.params) / md > DELTA_S
                       for u in survivors):
                survivors.append(a)
        final = [a for a in survivors if not (a.e_i < DELTA_F and len(a.H_i) >= 3)]
        while len(final) < 10 and len(survivors) > len(final):
            for a in sorted(survivors, key=lambda a: a.e_i, reverse=True):
                if a not in final: final.append(a); break
        for top in sorted(population, key=lambda a: a.e_i, reverse=True)[:3]:
            ar = Agent(top.params, pwm)
            ar.e_i, ar.H_i, ar.mu_i = top.e_i, top.H_i[:], top.mu_i
            archive.append(ar)
        archive.sort(key=lambda a: a.e_i, reverse=True)
        archive    = archive[:A_MAX]
        pool       = final + archive
        population = final[:]
        while len(population) < N_POP:
            cands = random.sample(pool, min(3, len(pool)))
            population.append(max(cands, key=lambda a: a.e_i).mutate())

    best_all = max(archive, key=lambda a: a.e_i) if archive else max(population, key=lambda a: a.e_i)
    return best_all.params, time.time() - t0, convergence


# ═══════════════════════════════════════════════════════════════
#  HEAD-TO-HEAD TOURNAMENT
# ═══════════════════════════════════════════════════════════════

def run_head_to_head(server, algo_weights, algo_names):
    """
    Run head-to-head tournament between all algorithm pairs.
    Returns a matrix of results: matrix[i][j] = (wins_i, losses_i, draws)
    """
    n = len(algo_names)
    # matrix[i][j] = (wins_for_i, losses_for_i, draws)
    matrix = [[None]*n for _ in range(n)]

    for i in range(n):
        for j in range(i+1, n):
            i_wins, j_wins, draws = 0, 0, 0
            for g in range(H2H_GAMES):
                # Alternate who plays P0/P1
                if g % 2 == 0:
                    winner, cyc = server.run_game_evolved_vs_evolved(
                        algo_weights[i], algo_weights[j])
                    if winner == 0:   i_wins += 1
                    elif winner == 1: j_wins += 1
                    else:             draws  += 1
                else:
                    winner, cyc = server.run_game_evolved_vs_evolved(
                        algo_weights[j], algo_weights[i])
                    if winner == 0:   j_wins += 1
                    elif winner == 1: i_wins += 1
                    else:             draws  += 1

            matrix[i][j] = (i_wins, j_wins, draws)
            matrix[j][i] = (j_wins, i_wins, draws)
            print(f"  {algo_names[i]:15s} vs {algo_names[j]:15s} → "
                  f"{i_wins}W-{j_wins}L-{draws}D")

    return matrix


def print_h2h_matrix(matrix, algo_names):
    """Print head-to-head results in the image format."""
    n = len(algo_names)
    col_w = 14  # column width

    # Compute totals
    total_wins = [0] * n
    total_games = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and matrix[i][j] is not None:
                w, l, d = matrix[i][j]
                total_wins[i]  += w
                total_games[i] += (w + l + d)
    win_rates = [total_wins[i] / total_games[i] * 100 if total_games[i] > 0 else 0
                 for i in range(n)]

    # Header
    header = f"  {'':17s}"
    for name in algo_names:
        header += f" {name:>{col_w}s}"
    header += f"  {'Wins':>6s}  {'WR%':>6s}"
    print(header)

    # Separator
    sep = "  " + "─" * 17
    for _ in algo_names:
        sep += " " + "─" * col_w
    sep += "  " + "─" * 6 + "  " + "─" * 6
    print(sep)

    # Rows
    for i in range(n):
        row = f"  {algo_names[i]:17s}"
        for j in range(n):
            if i == j:
                row += f" {'—':>{col_w}s}"
            else:
                w, l, d = matrix[i][j]
                cell = f"{w}W-{l}L-{d}D"
                row += f" {cell:>{col_w}s}"
        row += f"  {total_wins[i]:>6d}  {win_rates[i]:>5.1f}%"
        print(row)

    print(sep)
    return total_wins, win_rates


# ═══════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════

def main():
    print("\n" + "#" * 70)
    print("  SEM7 PR1 — Head-to-Head Algorithm Comparison")
    print("  64×64 Dynamic Map with Progressive Blockades")
    print("#" * 70)
    print(f"  Pop={N_POP} | Gens={TOTAL_GENERATIONS} | K={K_GAMES} | "
          f"H2H Games={H2H_GAMES}/pair | Map=64×64")
    print(f"  Algorithms: CCE-TDCCEA, TD-CCEA, SA-TDCCEA, Standard CCEA\n")

    # ──────────────────────────────────────────────────────────────
    #  PHASE 0: Sensitivity analysis (needed for SA-TDCCEA)
    # ──────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  PHASE 0: Loading/Running Sensitivity Analysis")
    print(f"{'='*60}")

    # Write initial clean map for sensitivity analysis
    write_map_xml(set(), set(), TEMP_MAP_PATH)
    print(f"  Wrote temp map: {TEMP_MAP_PATH}")
    print(f"  Temp map exists: {os.path.isfile(TEMP_MAP_PATH)}")

    sa_server = GameServer()
    sa_server.start()

    # Run diagnostic test game to verify server+map work
    if not sa_server.run_test_game():
        print("\n  *** DIAGNOSTIC FAILED ***")
        print("  The Java game server cannot run games on the 64x64 map.")
        print("  Possible causes:")
        print("    1. The map XML format is invalid for this server version")
        print("    2. The Java EvolvedBatchGameRunner doesn't support 64x64")
        print("    3. The temp map path is wrong")
        print(f"  Map path (abs): {TEMP_MAP_PATH}")
        print(f"  Map path (rel): {TEMP_MAP_REL}")
        sa_server.stop()
        return

    sa_mut = load_or_run_sensitivity(sa_server)
    sa_server.stop()
    print()

    # ──────────────────────────────────────────────────────────────
    #  PHASE 1: EVOLUTION (with dynamic blockades)
    # ──────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  PHASE 1: EVOLUTION — 4 Algorithms × {TOTAL_GENERATIONS} Generations")
    print(f"  Dynamic blockades added each generation (BFS-validated)")
    print(f"{'='*60}")

    algos = [
        ("CCE-TDCCEA",    "ccea"),
        ("TD-CCEA",       "tdccea"),
        ("SA-TDCCEA",     "sa_tdccea"),
        ("Std CCEA",      "std_ccea"),
    ]

    terrain_walls       = set()
    breakable_positions = set()
    results             = []

    for algo_name, algo_key in algos:
        # Reset dynamic map for each algorithm (fair comparison)
        terrain_walls_algo   = set()
        breakable_positions_algo = set()

        # Start fresh server
        server = GameServer()
        server.start()
        print(f"\n  [OK] Server started — {algo_name}")

        # Add progressive blockades generation by generation
        # We pre-compute the wall schedule so evolution uses dynamic map
        t_algo_start = time.time()

        # Build the wall schedule (same random seed offset per algo for fairness)
        wall_schedule = []
        tw_temp, bp_temp = set(), set()
        for gen in range(1, TOTAL_GENERATIONS + 1):
            tw_temp, bp_temp, nt, nb = add_walls_for_generation(
                gen, tw_temp, bp_temp)
            wall_schedule.append((set(tw_temp), set(bp_temp), nt, nb))

        # Write the final map state for this algorithm
        final_tw, final_bp = wall_schedule[-1][0], wall_schedule[-1][1]

        # For evolution, write map with generation-appropriate walls
        # We'll write the map before the algorithm runs with its final walls
        write_map_xml(final_tw, final_bp, TEMP_MAP_PATH)
        total_walls = len(final_tw) + len(final_bp)
        print(f"  Map: {total_walls} total walls "
              f"({len(final_tw)} terrain + {len(final_bp)} breakable)")

        # Run algorithm
        if algo_key == "ccea":
            best, elapsed, conv = run_ccea(server)
        elif algo_key == "std_ccea":
            best, elapsed, conv = run_standard_ccea(server)
        elif algo_key == "tdccea":
            best, elapsed, conv = evolve_core(server, "TD-CCEA")
        elif algo_key == "sa_tdccea":
            best, elapsed, conv = evolve_core(server, "SA-TDCCEA", pwm=sa_mut)

        # Validate against all bots
        print(f"\n  Validating {algo_name} against all 7 bots...")
        wr, per_opp = validate_weights(server, best)
        server.stop()

        elapsed_total = time.time() - t_algo_start
        print(f"  {algo_name}: {wr:.1f}% overall in {elapsed_total:.1f}s")

        results.append({
            "name":     algo_name,
            "key":      algo_key,
            "time":     elapsed_total,
            "wr":       wr,
            "per_opp":  per_opp,
            "weights":  best,
            "convergence": conv,
        })

        # Store final walls for the tournament
        terrain_walls       = final_tw
        breakable_positions = final_bp

    # ──────────────────────────────────────────────────────────────
    #  RANKING TABLE (vs bots)
    # ──────────────────────────────────────────────────────────────
    ranked = sorted(results, key=lambda x: x["wr"], reverse=True)
    medals = ["1st","2nd","3rd","4th"]

    print(f"\n{'='*60}")
    print(f"  RANKING — Win Rate vs 7 Bots")
    print(f"{'='*60}")
    print(f"  {'Rank':<6s} {'Algorithm':<18s} {'Win Rate':>10s} {'Time':>8s}")
    print(f"  {'_'*6} {'_'*18} {'_'*10} {'_'*8}")
    for i, r in enumerate(ranked):
        print(f"  {medals[i]:<6s} {r['name']:<18s} {r['wr']:>9.1f}%  {r['time']:>7.1f}s")

    # ── PER-BOT TABLE ────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  WIN RATE PER BOT (%)")
    print(f"{'='*60}")
    header = f"  {'Bot':<26s}"
    for r in ranked: header += f" {r['name'][:12]:>13s}"
    print(header)
    print("  " + "-" * (26 + 14 * len(ranked)))
    for opp in OPPONENT_ROTATION:
        row   = f"  {opp:<26s}"
        rates = [r["per_opp"].get(opp, 0) for r in ranked]
        mx    = max(rates)
        for r in ranked:
            w  = r["per_opp"].get(opp, 0)
            mk = "*" if w == mx and rates.count(mx) == 1 else " "
            row += f" {w:>11.0f}%{mk}"
        print(row)
    print("  " + "-" * (26 + 14 * len(ranked)))

    # ──────────────────────────────────────────────────────────────
    #  PHASE 2: HEAD-TO-HEAD TOURNAMENT
    # ──────────────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  PHASE 2: HEAD-TO-HEAD TOURNAMENT")
    print(f"  Each pair plays {H2H_GAMES} games (alternating P0/P1)")
    print(f"  Map: 64×64 with {len(terrain_walls) + len(breakable_positions)} blockades")
    print(f"{'='*70}\n")

    # Write tournament map
    write_map_xml(terrain_walls, breakable_positions, TEMP_MAP_PATH)

    h2h_server = GameServer()
    h2h_server.start()

    algo_names   = [r["name"] for r in results]
    algo_weights = [r["weights"] for r in results]
    matrix = run_head_to_head(h2h_server, algo_weights, algo_names)
    h2h_server.stop()

    # Print matrix
    print(f"\n{'='*70}")
    print(f"  HEAD-TO-HEAD RESULTS MATRIX")
    print(f"{'='*70}\n")
    total_wins, win_rates = print_h2h_matrix(matrix, algo_names)

    # ──────────────────────────────────────────────────────────────
    #  PHASE 3: STATISTICAL ANALYSIS
    # ──────────────────────────────────────────────────────────────

    # ── WILCOXON SIGNED-RANK TEST ────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  STATISTICAL SIGNIFICANCE — Wilcoxon Signed-Rank Test")
    print(f"  (CCE-TDCCEA vs each baseline, per-bot win rates as samples)")
    print(f"{'='*70}")

    cce = next((r for r in results if r["key"] == "ccea"), None)
    wilcoxon_lines = []
    wilcoxon_lines.append(f"Wilcoxon Signed-Rank Test Results")
    wilcoxon_lines.append(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    wilcoxon_lines.append(f"Map: 64×64 dynamic blockades")
    wilcoxon_lines.append(f"Generations: {TOTAL_GENERATIONS}, Pop: {N_POP}, K_Games: {K_GAMES}")
    wilcoxon_lines.append(f"Reference algorithm: CCE-TDCCEA")
    wilcoxon_lines.append("")
    wilcoxon_lines.append(f"{'Baseline':<20s}  {'p-value':>9s}  {'Significant?':>13s}  Direction")
    wilcoxon_lines.append(f"{'_'*20}  {'_'*9}  {'_'*13}  {'_'*22}")

    if cce:
        cce_rates = [cce["per_opp"].get(o, 0) for o in OPPONENT_ROTATION]
        print(f"\n  {'Baseline':<20s}  {'p-value':>9s}  {'Significant?':>13s}  Direction")
        print(f"  {'_'*20}  {'_'*9}  {'_'*13}  {'_'*22}")
        for r in results:
            if r["key"] == "ccea": continue
            other = [r["per_opp"].get(o, 0) for o in OPPONENT_ROTATION]
            p     = wilcoxon_test(cce_rates, other)
            if p is None:
                line = f"{r['name']:<20s}  {'N/A':>9s}  {'N/A':>13s}  —"
            else:
                sig  = "YES (p<0.05)" if p < 0.05 else "NO  (p>=0.05)"
                dirn = ("CCE-TDCCEA BETTER" if sum(cce_rates) > sum(other)
                        else "BASELINE BETTER")
                line = f"{r['name']:<20s}  {p:>9.4f}  {sig:>13s}  {dirn}"
            print(f"  {line}")
            wilcoxon_lines.append(line)

    # Add head-to-head Wilcoxon section
    wilcoxon_lines.append("")
    wilcoxon_lines.append("=" * 60)
    wilcoxon_lines.append("Head-to-Head Tournament Summary")
    wilcoxon_lines.append("=" * 60)
    for i, name in enumerate(algo_names):
        games = sum(1 for j in range(len(algo_names)) if i != j)
        wilcoxon_lines.append(
            f"{name:<17s}  Total Wins: {total_wins[i]:>3d}  "
            f"Win Rate: {win_rates[i]:>5.1f}%")

    # Save wilcoxon_results.txt
    wilcoxon_path = os.path.join(SCRIPT_DIR, "wilcoxon_results.txt")
    with open(wilcoxon_path, "w", encoding="utf-8") as f:
        f.write("\n".join(wilcoxon_lines) + "\n")
    print(f"\n  Saved → {wilcoxon_path}")

    # ── ABLATION ANALYSIS ────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  ABLATION ANALYSIS")
    print(f"{'='*70}")

    ablation_lines = []
    ablation_lines.append(f"Ablation Analysis Results")
    ablation_lines.append(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    ablation_lines.append(f"Map: 64×64 dynamic blockades")
    ablation_lines.append(f"Generations: {TOTAL_GENERATIONS}, Pop: {N_POP}, K_Games: {K_GAMES}")
    ablation_lines.append("")

    cce   = next((r for r in results if r["key"] == "ccea"),     None)
    sccea = next((r for r in results if r["key"] == "std_ccea"), None)
    cent  = next((r for r in results if r["key"] == "tdccea"),   None)
    sa    = next((r for r in results if r["key"] == "sa_tdccea"),None)

    # 1. Trajectory memory contribution: CCE-TDCCEA vs Std CCEA
    if cce and sccea:
        d = cce["wr"] - sccea["wr"]
        lines_out = [
            f"1. Trajectory Memory Contribution",
            f"   CCE-TDCCEA ({cce['wr']:.1f}%) vs Std CCEA ({sccea['wr']:.1f}%)",
            f"   Difference: {d:+.1f}%",
            f"   Result: {'Trajectory HELPS' if d >= 0 else 'Trajectory HURTS'} ({abs(d):.1f}%)",
            "",
        ]
        for line in lines_out: print(f"  {line}")
        ablation_lines.extend(lines_out)

    # 2. Cooperative decomposition: CCE-TDCCEA vs TD-CCEA
    if cce and cent:
        d = cce["wr"] - cent["wr"]
        lines_out = [
            f"2. Cooperative Decomposition Contribution",
            f"   CCE-TDCCEA ({cce['wr']:.1f}%) vs TD-CCEA ({cent['wr']:.1f}%)",
            f"   Difference: {d:+.1f}%",
            f"   Result: {'Decomposition HELPS' if d >= 0 else 'Decomposition HURTS'} ({abs(d):.1f}%)",
            "",
        ]
        for line in lines_out: print(f"  {line}")
        ablation_lines.extend(lines_out)

    # 3. Sensitivity-adaptive mutation: SA-TDCCEA vs TD-CCEA
    if sa and cent:
        d = sa["wr"] - cent["wr"]
        lines_out = [
            f"3. Sensitivity-Adaptive Mutation Contribution",
            f"   SA-TDCCEA ({sa['wr']:.1f}%) vs TD-CCEA ({cent['wr']:.1f}%)",
            f"   Difference: {d:+.1f}%",
            f"   Result: {'SA Mutation HELPS' if d >= 0 else 'SA Mutation HURTS'} ({abs(d):.1f}%)",
            "",
        ]
        for line in lines_out: print(f"  {line}")
        ablation_lines.extend(lines_out)

    # 4. Full novel contribution: CCE-TDCCEA vs SA-TDCCEA
    if cce and sa:
        d = cce["wr"] - sa["wr"]
        lines_out = [
            f"4. Full Novel Contribution (CCE-TDCCEA vs SA-TDCCEA)",
            f"   CCE-TDCCEA ({cce['wr']:.1f}%) vs SA-TDCCEA ({sa['wr']:.1f}%)",
            f"   Difference: {d:+.1f}%",
            f"   Result: {'CCE-TDCCEA BETTER' if d >= 0 else 'SA-TDCCEA BETTER'} ({abs(d):.1f}%)",
            "",
        ]
        for line in lines_out: print(f"  {line}")
        ablation_lines.extend(lines_out)

    # Add head-to-head summary to ablation
    ablation_lines.append("=" * 60)
    ablation_lines.append("Head-to-Head Tournament Results")
    ablation_lines.append("=" * 60)
    ablation_lines.append("")
    # Reproduce matrix in text form
    col_w = 14
    header_line = f"{'':17s}"
    for name in algo_names:
        header_line += f" {name:>{col_w}s}"
    header_line += f"  {'Wins':>6s}  {'WR%':>6s}"
    ablation_lines.append(header_line)
    sep_line = "─" * 17
    for _ in algo_names:
        sep_line += " " + "─" * col_w
    sep_line += "  " + "─" * 6 + "  " + "─" * 6
    ablation_lines.append(sep_line)
    for i in range(len(algo_names)):
        row = f"{algo_names[i]:17s}"
        for j in range(len(algo_names)):
            if i == j:
                row += f" {'—':>{col_w}s}"
            else:
                w, l, d = matrix[i][j]
                cell = f"{w}W-{l}L-{d}D"
                row += f" {cell:>{col_w}s}"
        row += f"  {total_wins[i]:>6d}  {win_rates[i]:>5.1f}%"
        ablation_lines.append(row)
    ablation_lines.append(sep_line)

    # Save ablation_results.txt
    ablation_path = os.path.join(SCRIPT_DIR, "ablation_results.txt")
    with open(ablation_path, "w", encoding="utf-8") as f:
        f.write("\n".join(ablation_lines) + "\n")
    print(f"\n  Saved → {ablation_path}")

    # ── SAVE JSON SUMMARY ────────────────────────────────────────
    json_data = {
        "meta": {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "map": "64×64 dynamic blockades",
            "generations": TOTAL_GENERATIONS,
            "pop_size": N_POP,
            "k_games": K_GAMES,
            "h2h_games": H2H_GAMES,
        },
        "vs_bots": [{
            "name": r["name"],
            "key": r["key"],
            "overall_winrate": r["wr"],
            "per_opponent": r["per_opp"],
            "time": r["time"],
        } for r in results],
        "head_to_head": {
            "algorithms": algo_names,
            "matrix": [
                [
                    {"wins": matrix[i][j][0],
                     "losses": matrix[i][j][1],
                     "draws": matrix[i][j][2]} if matrix[i][j] else None
                    for j in range(len(algo_names))
                ]
                for i in range(len(algo_names))
            ],
            "total_wins": total_wins,
            "win_rates": win_rates,
        },
    }
    json_path = os.path.join(SCRIPT_DIR, "pr1_results.json")
    with open(json_path, "w") as f:
        json.dump(json_data, f, indent=2)
    print(f"\n  Saved → {json_path}")

    # ── FINAL SUMMARY ────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  SEM7 PR1 BENCHMARK COMPLETE!")
    print(f"{'='*70}")
    print(f"  Output files (in PR1_Sem7/):")
    print(f"    • wilcoxon_results.txt")
    print(f"    • ablation_results.txt")
    print(f"    • pr1_results.json")
    print(f"{'='*70}\n")


if __name__ == "__main__":
    main()
